package com.kirana.pos;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.ActivityNotFoundException;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
  private static final int CAMERA_PERMISSION_REQUEST = 701;
  private WebView webView;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url.startsWith("sms:") || url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/")) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
          catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Please install WhatsApp or a messaging app", Toast.LENGTH_LONG).show(); }
          return true;
        }
        return false;
      }
    });
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    webView.addJavascriptInterface(new ScannerBridge(), "AndroidScanner");
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
  }

  private void startBarcodeScan() {
    if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
      return;
    }
    launchScanner();
  }

  private void launchScanner() {
    try {
      IntentIntegrator integrator = new IntentIntegrator(this);
      integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
      integrator.setPrompt("Scan product barcode");
      integrator.setBeepEnabled(true);
      integrator.setOrientationLocked(false);
      integrator.setCaptureActivity(com.journeyapps.barcodescanner.CaptureActivity.class);
      integrator.initiateScan();
    } catch (Exception e) {
      Toast.makeText(this, "Unable to open barcode scanner. Please check camera permission.", Toast.LENGTH_LONG).show();
    }
  }

  private class ScannerBridge {
    @JavascriptInterface public void scan() { runOnUiThread(() -> startBarcodeScan()); }
  }

  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == CAMERA_PERMISSION_REQUEST) {
      if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchScanner();
      else Toast.makeText(this, "Camera permission is needed to scan barcodes.", Toast.LENGTH_LONG).show();
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
    if (result != null) {
      if (result.getContents() != null && webView != null) {
        String value = org.json.JSONObject.quote(result.getContents());
        webView.evaluateJavascript("window.onBarcodeScanned && window.onBarcodeScanned(" + value + ")", null);
      }
      return;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }
}

package com.kirana.pos;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {
  private WebView webView;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient());
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    webView.addJavascriptInterface(new ScannerBridge(), "AndroidScanner");
    webView.loadUrl("file:///android_asset/index.html");
    setContentView(webView);
  }
  private class ScannerBridge {
    @JavascriptInterface public void scan() {
      runOnUiThread(() -> {
        IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scan product barcode");
        integrator.setBeepEnabled(true);
        integrator.setOrientationLocked(false);
        integrator.initiateScan();
      });
    }
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
    if (result != null) {
      if (result.getContents() != null && webView != null) {
        String value = org.json.JSONObject.quote(result.getContents());
        webView.evaluateJavascript("window.onBarcodeScanned && window.onBarcodeScanned(" + value + ")", null);
      }
      return;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }
}

# Mahalaxmi General Store — Kirana POS No GST

Preconfigured shop:
- Name: Mahalaxmi General Store
- Address: New Colony, Kuchaman City

GST/tax fields are disabled.

Features:
- Cash / UPI / Card / Udhaar billing
- Product and stock management
- Barcode/search field
- Customer ledger and Udhaar payments
- Sales reports
- Printable receipt
- Offline/local storage

This is source code and needs an Android build environment to create an APK.
